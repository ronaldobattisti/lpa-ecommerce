<?php
// Site-wide config
// Adjust BASE_URL to match the web-accessible path of your project
// e.g. if you access via http://localhost/LPA_eComms/ then use '/LPA_eComms'
// If you run at the webroot (http://localhost/) use ''

if (!defined('BASE_URL')) {
    define('BASE_URL', "/LPA_eComms/web");
}

?>