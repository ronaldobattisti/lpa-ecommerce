<?php
    /*define("BASE_URL", "http://localhost/LPA_eComms/web");
    define("DB_HOST", "localhost");
    define("DB_USER", "root");
    define("DB_PASS", "");
    define("DB_NAME", "lpa_ecomms");*/
    define("BASE_URL", "http://www.ronaldobattisti.space");
    define("DB_HOST", "localhost");
    define("DB_USER", "ronaldob");
    define("DB_PASS", "6q9(9QBin*fGL3");
    define("DB_NAME", "ronaldob_lpa_ecomms");
?>