<?php
    define("BASE_URL", "ecomms.wuaze.com");
    define("DB_HOST", "sql303.infinityfree.com");
    define("DB_USER", "if0_40513248");
    define("DB_PASS", "Rb19962025 ");
    define("DB_NAME", "if0_40513248_lpa_ecomms");
?>