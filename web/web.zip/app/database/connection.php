<?php
    //database connection
    //$conn = new mysqli("sql303.infinityfree.com", "if0_40513248", "Rb19962025", "if0_40513248_lpa_ecomms");
    $conn = new mysqli("localhost", "root", "", "lpa_ecomms");
    if($conn->connect_error){
        die("Connection failed: " . $conn->connect_error);
    }
?>