<div>
    <label for="category">Category:</label>
    <select id="category" name="category">
        <option value="desktop">Desktop</option>
        <option value="laptop">Laptop</option>
        <option value="component">Component</option>
        <option value="storage">Storage</option>
        <option value="peripheral">Perihperal</option>
        <option value="display">Display</option>
        <option value="network">Network</option>
        <option value="printer">Printer</option>
    </select>
</div>