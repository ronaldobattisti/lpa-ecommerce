<div>
    <label for="category">Category:</label>
    <select id="category" name="category">
        <option value="to_pay">To pay</option>
        <option value="to_ship">To ship</option>
        <option value="shipped">Shipped</option>
        <option value="processed">Processed</option>
        <option value="canceled">Canceled</option>
    </select>
</div>